# F1e (#127) investigation runs — manifest

Base: integration `6edcfeb5318e0ab951c02f6f97add4191d799be2` (merge of #131), worktree `bft-core-f1e`, branch
`f1e/consensus-trace`, no source change. Host: macOS 15.7.9, Intel Core i7-8850H (darwin/amd64), 12 logical
CPUs, 16 GiB. Local toolchain go1.27.1 darwin/amd64; go.mod says `go 1.24`. Every run `-count=1 -json`,
one at a time (no concurrent test runs), from the worktree root.

| run | test | toolchain / platform | log level | result |
|---|---|---|---|---|
| 1 | `^Test_rootNetworkRunning$` | go1.27.1 darwin/amd64 | default | FAIL 6.54s: "waiting for round 10 to be achieved" (reached 8–9) |
| 2 | `^Test_recoverState$` | go1.27.1 darwin/amd64 | default | FAIL: 8/9 subtests; only dead_leader passes (18.71s) |
| 3 | `^Test_rootNetworkRunning$` | go1.24.6 darwin/amd64 | default | PASS 6.64s; 68 messages in 5.10s (~600 ms/round) |
| 4 | `^Test_recoverState$` | go1.24.6 darwin/amd64 | default | FAIL: same 8/9 subtests |
| 5 | `^Test_rootNetworkRunning$` | go1.27.1 darwin/amd64 | DEBUG | PASS; rounds 500–600 ms each |
| 6 | `^Test_recoverState$/^late_joiner_catches_up$` | go1.27.1 darwin/amd64 | DEBUG | FAIL 5.54s at consensus_recovery_test.go:314, "waiting for sleepy consensus manager to catch up" |
| L1 | both tests | golang:1.24 image, go1.24.13 linux/amd64, 2 CPUs, Docker 29.5.2 on the same Mac | default | **all PASS**: rootNetworkRunning 1.41s; recoverState 9/9 (0.49–5.07s) |
